import { useState, useEffect } from "react";
import { Dashboard } from "@/components/Dashboard";
import { TransactionForm } from "@/components/TransactionForm";
import { ExpenseList } from "@/components/ExpenseList";
import { ExpenseCharts } from "@/components/ExpenseCharts";
import { BudgetManager } from "@/components/BudgetManager";
import { InsightsPanel } from "@/components/InsightsPanel";
import { SavingSuggestions } from "@/components/SavingSuggestions";
import { Wallet } from "lucide-react";
import { smartCategorize } from "@/lib/smartCategorize";
import { toast } from "sonner";

interface Transaction {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  type: "income" | "expense";
}

const CATEGORIES = ["Food", "Transport", "Entertainment", "Shopping", "Bills", "Health", "Salary", "Investment", "Other"];

const Index = () => {
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem("transactions");
    return saved ? JSON.parse(saved) : [];
  });

  const [monthlyBudget, setMonthlyBudget] = useState<number>(() => {
    const saved = localStorage.getItem("monthlyBudget");
    return saved ? parseFloat(saved) : 50000;
  });

  const [weeklyBudget, setWeeklyBudget] = useState<number>(() => {
    const saved = localStorage.getItem("weeklyBudget");
    return saved ? parseFloat(saved) : 12000;
  });

  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);

  useEffect(() => {
    localStorage.setItem("transactions", JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem("monthlyBudget", monthlyBudget.toString());
  }, [monthlyBudget]);

  useEffect(() => {
    localStorage.setItem("weeklyBudget", weeklyBudget.toString());
  }, [weeklyBudget]);

  // Budget alert check
  useEffect(() => {
    const currentMonthExpenses = transactions
      .filter(t => t.type === "expense" && new Date(t.date).getMonth() === new Date().getMonth())
      .reduce((sum, t) => sum + t.amount, 0);
    
    const budgetUsage = (currentMonthExpenses / monthlyBudget) * 100;
    
    if (budgetUsage >= 90) {
      toast.error("⚠️ Alert: You've used 90% of your monthly budget!");
    } else if (budgetUsage >= 75) {
      toast.warning("⚠️ Warning: You've used 75% of your monthly budget!");
    }
  }, [transactions, monthlyBudget]);

  const addTransaction = (transaction: Omit<Transaction, "id">) => {
    const category = smartCategorize(transaction.description, transaction.category);
    const newTransaction = {
      ...transaction,
      category,
      id: Date.now().toString(),
    };
    setTransactions((prev) => [newTransaction, ...prev]);
    toast.success(`${transaction.type === "income" ? "Income" : "Expense"} added successfully!`);
  };

  const updateTransaction = (id: string, transaction: Omit<Transaction, "id">) => {
    const category = smartCategorize(transaction.description, transaction.category);
    setTransactions((prev) =>
      prev.map((t) => (t.id === id ? { ...transaction, category, id } : t))
    );
    setEditingTransaction(null);
    toast.success("Transaction updated successfully!");
  };

  const deleteTransaction = (id: string) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
    toast.success("Transaction deleted!");
  };

  const updateBudget = (monthly: number, weekly: number) => {
    setMonthlyBudget(monthly);
    setWeeklyBudget(weekly);
  };

  const expenses = transactions.filter(t => t.type === "expense");

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/30">
      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Header */}
        <header className="text-center space-y-4 py-8">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 rounded-2xl bg-primary/10">
              <Wallet className="h-10 w-10 text-primary" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary via-primary-light to-accent bg-clip-text text-transparent">
            Smart Expense Tracker
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Take control of your finances with intelligent expense tracking and insightful analytics
          </p>
        </header>

        {/* Dashboard Stats */}
        <Dashboard transactions={transactions} monthlyBudget={monthlyBudget} weeklyBudget={weeklyBudget} />

        {/* Insights and Suggestions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <InsightsPanel transactions={transactions} />
          <SavingSuggestions transactions={transactions} monthlyBudget={monthlyBudget} />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Forms */}
          <div className="lg:col-span-1 space-y-6">
            <TransactionForm 
              onAddTransaction={addTransaction} 
              onUpdateTransaction={updateTransaction}
              categories={CATEGORIES}
              editingTransaction={editingTransaction}
              onCancelEdit={() => setEditingTransaction(null)}
            />
            <BudgetManager 
              monthlyBudget={monthlyBudget} 
              weeklyBudget={weeklyBudget}
              onUpdateBudget={updateBudget} 
            />
          </div>

          {/* Right Column - Lists and Charts */}
          <div className="lg:col-span-2 space-y-6">
            <ExpenseCharts transactions={transactions} />
            <ExpenseList
              transactions={transactions}
              categories={CATEGORIES}
              onDeleteTransaction={deleteTransaction}
              onEditTransaction={setEditingTransaction}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
