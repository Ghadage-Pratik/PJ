// Smart categorization based on keywords
const categoryKeywords: Record<string, string[]> = {
  Food: [
    "zomato", "swiggy", "restaurant", "cafe", "food", "lunch", "dinner", 
    "breakfast", "meal", "pizza", "burger", "biryani", "dominos", "mcdonald",
    "kfc", "subway", "starbucks", "chai", "coffee", "grocery", "vegetables"
  ],
  Transport: [
    "uber", "ola", "rapido", "metro", "bus", "taxi", "petrol", "diesel",
    "fuel", "parking", "toll", "train", "flight", "indigo", "spicejet"
  ],
  Entertainment: [
    "movie", "cinema", "netflix", "spotify", "amazon prime", "hotstar",
    "youtube", "game", "concert", "show", "theatre", "bookmyshow"
  ],
  Shopping: [
    "amazon", "flipkart", "myntra", "ajio", "shopping", "clothes", "shoes",
    "electronics", "mobile", "laptop", "fashion", "meesho", "nykaa"
  ],
  Bills: [
    "electricity", "water", "gas", "internet", "broadband", "mobile bill",
    "recharge", "rent", "maintenance", "subscription", "insurance", "emi"
  ],
  Health: [
    "hospital", "doctor", "medicine", "pharmacy", "medical", "gym",
    "fitness", "apollo", "medplus", "netmeds", "practo", "health"
  ],
  Salary: [
    "salary", "income", "payment received", "credited", "wages", "bonus"
  ],
  Investment: [
    "mutual fund", "stock", "investment", "trading", "zerodha", "groww",
    "fixed deposit", "fd", "savings"
  ]
};

export const smartCategorize = (description: string, defaultCategory: string): string => {
  const lowerDesc = description.toLowerCase();
  
  for (const [category, keywords] of Object.entries(categoryKeywords)) {
    if (keywords.some(keyword => lowerDesc.includes(keyword))) {
      return category;
    }
  }
  
  return defaultCategory;
};
