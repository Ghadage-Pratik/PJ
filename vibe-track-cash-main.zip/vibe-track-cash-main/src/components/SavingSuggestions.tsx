import { Card } from "@/components/ui/card";
import { Lightbulb, TrendingDown } from "lucide-react";

interface Transaction {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  type: "income" | "expense";
}

interface SavingSuggestionsProps {
  transactions: Transaction[];
  monthlyBudget: number;
}

export const SavingSuggestions = ({ transactions, monthlyBudget }: SavingSuggestionsProps) => {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  // Calculate category-wise spending
  const categorySpending: Record<string, number> = {};
  transactions
    .filter(t => {
      const date = new Date(t.date);
      return t.type === "expense" && 
             date.getMonth() === currentMonth && 
             date.getFullYear() === currentYear;
    })
    .forEach(t => {
      categorySpending[t.category] = (categorySpending[t.category] || 0) + t.amount;
    });

  const suggestions: string[] = [];

  // Generate smart suggestions
  if (categorySpending["Food"] > monthlyBudget * 0.3) {
    suggestions.push("🍽️ Your food expenses are high. Try cooking at home more often to save ₹" + 
                    (categorySpending["Food"] * 0.3).toFixed(0));
  }

  if (categorySpending["Entertainment"] > monthlyBudget * 0.15) {
    suggestions.push("🎬 Consider reducing entertainment expenses. You could save ₹" + 
                    (categorySpending["Entertainment"] * 0.4).toFixed(0) + " monthly");
  }

  if (categorySpending["Shopping"] > monthlyBudget * 0.2) {
    suggestions.push("🛍️ Shopping expenses are above ideal. Plan purchases and avoid impulse buying");
  }

  if (categorySpending["Transport"] > monthlyBudget * 0.15) {
    suggestions.push("🚗 Try carpooling or using public transport to reduce travel costs");
  }

  // Default suggestions
  if (suggestions.length === 0) {
    suggestions.push("💰 Great job! Your spending is well balanced");
    suggestions.push("📊 Set up automatic savings to build your emergency fund");
    suggestions.push("🎯 Consider investing 20% of your income for long-term goals");
  }

  // Expected next month spending
  const totalExpenses = Object.values(categorySpending).reduce((sum, val) => sum + val, 0);
  const daysInMonth = new Date().getDate();
  const projectedMonthlyExpense = (totalExpenses / daysInMonth) * 30;

  return (
    <Card className="p-6">
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
        <Lightbulb className="h-5 w-5 text-warning" />
        Smart Suggestions
      </h2>
      
      <div className="space-y-4">
        {/* Projected Spending */}
        <div className="p-4 rounded-lg bg-gradient-to-r from-chart-1/10 to-chart-2/10 border border-chart-1/20">
          <div className="flex items-center gap-2 mb-2">
            <TrendingDown className="h-5 w-5 text-chart-1" />
            <span className="text-sm font-medium">Expected Month-End Spending</span>
          </div>
          <span className="text-2xl font-bold text-chart-1">₹{projectedMonthlyExpense.toFixed(0)}</span>
          <p className="text-xs text-muted-foreground mt-1">
            Based on current spending pattern
          </p>
        </div>

        {/* Suggestions List */}
        <div className="space-y-2">
          <p className="text-sm font-medium text-muted-foreground">Personalized Tips</p>
          {suggestions.map((suggestion, index) => (
            <div 
              key={index}
              className="p-3 rounded-lg bg-muted/50 text-sm border-l-4 border-primary"
            >
              {suggestion}
            </div>
          ))}
        </div>

        {/* Quick Saving Tips */}
        <div className="p-4 rounded-lg bg-success/10 border border-success/20">
          <p className="text-sm font-medium text-success mb-2">💡 Quick Saving Tip</p>
          <p className="text-sm text-muted-foreground">
            Follow the 50-30-20 rule: 50% needs, 30% wants, 20% savings
          </p>
        </div>
      </div>
    </Card>
  );
};
