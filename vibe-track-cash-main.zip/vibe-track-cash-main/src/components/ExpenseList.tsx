import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Trash2, Calendar, IndianRupee, Tag, Edit, TrendingUp, TrendingDown } from "lucide-react";

interface Transaction {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  type: "income" | "expense";
}

interface ExpenseListProps {
  transactions: Transaction[];
  categories: string[];
  onDeleteTransaction: (id: string) => void;
  onEditTransaction: (transaction: Transaction) => void;
}

export const ExpenseList = ({ transactions, categories, onDeleteTransaction, onEditTransaction }: ExpenseListProps) => {
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [filterType, setFilterType] = useState<string>("all");

  const filteredTransactions = transactions.filter(
    (t) => (filterCategory === "all" || t.category === filterCategory) &&
           (filterType === "all" || t.type === filterType)
  );

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Food: "chart-3",
      Transport: "chart-4",
      Entertainment: "chart-1",
      Shopping: "chart-2",
      Bills: "chart-5",
      Health: "success",
      Other: "muted",
    };
    return colors[category] || "muted";
  };

  return (
    <Card className="p-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <h2 className="text-xl font-bold">Recent Transactions</h2>
        <div className="flex gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Filter type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="expense">Expenses</SelectItem>
              <SelectItem value="income">Income</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {filteredTransactions.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <IndianRupee className="h-12 w-12 mx-auto mb-3 opacity-50" />
          <p>No transactions yet. Start tracking your finances!</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredTransactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-4 rounded-lg border bg-card hover:shadow-md transition-all duration-200"
            >
              <div className="flex items-center gap-4 flex-1 min-w-0">
                <div
                  className={`p-2 rounded-lg ${transaction.type === 'income' ? 'bg-success/10' : 'bg-chart-1/10'} flex-shrink-0`}
                >
                  {transaction.type === 'income' ? (
                    <TrendingUp className="h-5 w-5 text-success" />
                  ) : (
                    <TrendingDown className="h-5 w-5 text-chart-1" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold truncate">{transaction.description}</p>
                  <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
                    <span className="flex items-center gap-1">
                      <Tag className="h-3 w-3" />
                      {transaction.category}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {new Date(transaction.date).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3 flex-shrink-0">
                <span className={`text-lg font-bold flex items-center gap-1 ${transaction.type === 'income' ? 'text-success' : 'text-chart-1'}`}>
                  <IndianRupee className="h-4 w-4" />
                  {transaction.amount.toFixed(2)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onEditTransaction(transaction)}
                  className="hover:bg-primary/10 hover:text-primary"
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onDeleteTransaction(transaction.id)}
                  className="hover:bg-destructive/10 hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};
