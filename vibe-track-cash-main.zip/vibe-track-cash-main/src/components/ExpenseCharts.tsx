import { Card } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, LineChart, Line, XAxis, YAxis, CartesianGrid } from "recharts";

interface Transaction {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  type: "income" | "expense";
}

interface ExpenseChartsProps {
  transactions: Transaction[];
}

export const ExpenseCharts = ({ transactions }: ExpenseChartsProps) => {
  const expenses = transactions.filter(t => t.type === "expense");
  
  const categoryData = expenses.reduce((acc, expense) => {
    const existing = acc.find((item) => item.name === expense.category);
    if (existing) {
      existing.value += expense.amount;
    } else {
      acc.push({ name: expense.category, value: expense.amount });
    }
    return acc;
  }, [] as Array<{ name: string; value: number }>);

  // Monthly trend data (last 6 months)
  const monthlyData = [];
  for (let i = 5; i >= 0; i--) {
    const date = new Date();
    date.setMonth(date.getMonth() - i);
    const month = date.toLocaleDateString('en-IN', { month: 'short' });
    
    const monthExpenses = transactions
      .filter(t => {
        const tDate = new Date(t.date);
        return t.type === "expense" && 
               tDate.getMonth() === date.getMonth() && 
               tDate.getFullYear() === date.getFullYear();
      })
      .reduce((sum, t) => sum + t.amount, 0);
    
    const monthIncome = transactions
      .filter(t => {
        const tDate = new Date(t.date);
        return t.type === "income" && 
               tDate.getMonth() === date.getMonth() && 
               tDate.getFullYear() === date.getFullYear();
      })
      .reduce((sum, t) => sum + t.amount, 0);
    
    monthlyData.push({ 
      month, 
      expenses: monthExpenses,
      income: monthIncome
    });
  }

  const COLORS = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
  ];

  if (transactions.length === 0) {
    return (
      <Card className="p-6">
        <h2 className="text-xl font-bold mb-4">Financial Overview</h2>
        <div className="h-[300px] flex items-center justify-center text-muted-foreground">
          Add transactions to see your financial breakdown
        </div>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Monthly Trend Line Chart */}
      <Card className="p-6">
        <h2 className="text-xl font-bold mb-4">6-Month Trend</h2>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip formatter={(value: number) => `₹${value.toFixed(0)}`} />
            <Legend />
            <Line 
              type="monotone" 
              dataKey="expenses" 
              stroke="hsl(var(--chart-1))" 
              strokeWidth={2}
              name="Expenses"
            />
            <Line 
              type="monotone" 
              dataKey="income" 
              stroke="hsl(var(--success))" 
              strokeWidth={2}
              name="Income"
            />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      {/* Category Pie Chart */}
      <Card className="p-6">
        <h2 className="text-xl font-bold mb-4">Spending by Category</h2>
        <ResponsiveContainer width="100%" height={300}>
          <PieChart>
            <Pie
              data={categoryData}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              outerRadius={80}
              fill="#8884d8"
              dataKey="value"
            >
              {categoryData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip formatter={(value: number) => `₹${value.toFixed(2)}`} />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
        <div className="mt-6 grid grid-cols-2 md:grid-cols-3 gap-3">
          {categoryData.map((item, index) => (
            <div key={item.name} className="flex items-center gap-2 p-2 rounded-lg bg-muted/50">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: COLORS[index % COLORS.length] }}
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{item.name}</p>
                <p className="text-sm text-muted-foreground">₹{item.value.toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};
