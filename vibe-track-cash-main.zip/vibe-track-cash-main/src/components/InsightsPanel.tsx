import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown, IndianRupee } from "lucide-react";

interface Transaction {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  type: "income" | "expense";
}

interface InsightsPanelProps {
  transactions: Transaction[];
}

export const InsightsPanel = ({ transactions }: InsightsPanelProps) => {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
  const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;

  const currentMonthExpenses = transactions
    .filter(t => {
      const date = new Date(t.date);
      return t.type === "expense" && 
             date.getMonth() === currentMonth && 
             date.getFullYear() === currentYear;
    })
    .reduce((sum, t) => sum + t.amount, 0);

  const lastMonthExpenses = transactions
    .filter(t => {
      const date = new Date(t.date);
      return t.type === "expense" && 
             date.getMonth() === lastMonth && 
             date.getFullYear() === lastMonthYear;
    })
    .reduce((sum, t) => sum + t.amount, 0);

  const difference = currentMonthExpenses - lastMonthExpenses;
  const percentageChange = lastMonthExpenses > 0 
    ? ((difference / lastMonthExpenses) * 100) 
    : 0;

  const isIncreased = difference > 0;

  // Get top spending category this month
  const categoryTotals: Record<string, number> = {};
  transactions
    .filter(t => {
      const date = new Date(t.date);
      return t.type === "expense" && 
             date.getMonth() === currentMonth && 
             date.getFullYear() === currentYear;
    })
    .forEach(t => {
      categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
    });

  const topCategory = Object.entries(categoryTotals)
    .sort(([, a], [, b]) => b - a)[0];

  return (
    <Card className="p-6">
      <h2 className="text-xl font-bold mb-4">Monthly Insights</h2>
      
      <div className="space-y-4">
        {/* Month Comparison */}
        <div className="p-4 rounded-lg bg-muted/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">vs Last Month</span>
            {isIncreased ? (
              <TrendingUp className="h-5 w-5 text-destructive" />
            ) : (
              <TrendingDown className="h-5 w-5 text-success" />
            )}
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-2xl font-bold ${isIncreased ? 'text-destructive' : 'text-success'}`}>
              {isIncreased ? '+' : ''}{percentageChange.toFixed(1)}%
            </span>
            <span className="text-sm text-muted-foreground">
              ({isIncreased ? '+' : ''}<IndianRupee className="inline h-3 w-3" />{Math.abs(difference).toFixed(0)})
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Last month: ₹{lastMonthExpenses.toFixed(0)} | This month: ₹{currentMonthExpenses.toFixed(0)}
          </p>
        </div>

        {/* Top Spending Category */}
        {topCategory && (
          <div className="p-4 rounded-lg bg-muted/50">
            <span className="text-sm font-medium">Top Spending Category</span>
            <div className="mt-2">
              <span className="text-2xl font-bold text-primary">{topCategory[0]}</span>
              <p className="text-sm text-muted-foreground mt-1">
                ₹{topCategory[1].toFixed(0)} spent this month
              </p>
            </div>
          </div>
        )}

        {/* Average Daily Spending */}
        <div className="p-4 rounded-lg bg-muted/50">
          <span className="text-sm font-medium">Average Daily Spending</span>
          <div className="mt-2">
            <span className="text-2xl font-bold text-chart-2 flex items-center gap-1">
              <IndianRupee className="h-6 w-6" />
              {(currentMonthExpenses / new Date().getDate()).toFixed(0)}
            </span>
            <p className="text-xs text-muted-foreground mt-1">
              Based on {new Date().getDate()} days this month
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
};
