import { Card } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Wallet, PiggyBank, IndianRupee } from "lucide-react";

interface Transaction {
  id: string;
  amount: number;
  category: string;
  description: string;
  date: string;
  type: "income" | "expense";
}

interface DashboardProps {
  transactions: Transaction[];
  monthlyBudget: number;
  weeklyBudget: number;
}

export const Dashboard = ({ transactions, monthlyBudget, weeklyBudget }: DashboardProps) => {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  
  const currentMonthTransactions = transactions.filter(t => {
    const tDate = new Date(t.date);
    return tDate.getMonth() === currentMonth && tDate.getFullYear() === currentYear;
  });

  const totalIncome = currentMonthTransactions
    .filter(t => t.type === "income")
    .reduce((sum, t) => sum + t.amount, 0);
  
  const totalExpenses = currentMonthTransactions
    .filter(t => t.type === "expense")
    .reduce((sum, t) => sum + t.amount, 0);
  
  const remaining = totalIncome - totalExpenses;
  const percentageUsed = monthlyBudget > 0 ? (totalExpenses / monthlyBudget) * 100 : 0;
  
  // Weekly calculation
  const getWeekStart = () => {
    const today = new Date();
    const day = today.getDay();
    const diff = today.getDate() - day + (day === 0 ? -6 : 1);
    return new Date(today.setDate(diff));
  };
  
  const weekStart = getWeekStart();
  const weeklyExpenses = transactions
    .filter(t => t.type === "expense" && new Date(t.date) >= weekStart)
    .reduce((sum, t) => sum + t.amount, 0);
  
  const weeklyPercentage = weeklyBudget > 0 ? (weeklyExpenses / weeklyBudget) * 100 : 0;

  const getProgressColor = (percentage: number) => {
    if (percentage >= 90) return "bg-destructive";
    if (percentage >= 75) return "bg-warning";
    if (percentage >= 50) return "bg-chart-2";
    return "bg-success";
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Total Income */}
      <Card className="p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-medium text-muted-foreground">Total Income</p>
          <TrendingUp className="h-5 w-5 text-success" />
        </div>
        <p className="text-3xl font-bold text-success flex items-center gap-1">
          <IndianRupee className="h-6 w-6" />
          {totalIncome.toFixed(2)}
        </p>
        <p className="text-xs text-muted-foreground mt-1">This month</p>
      </Card>

      {/* Total Expenses */}
      <Card className="p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
          <TrendingDown className="h-5 w-5 text-chart-1" />
        </div>
        <p className="text-3xl font-bold text-chart-1 flex items-center gap-1">
          <IndianRupee className="h-6 w-6" />
          {totalExpenses.toFixed(2)}
        </p>
        <p className="text-xs text-muted-foreground mt-1">This month</p>
      </Card>

      {/* Remaining Balance */}
      <Card className="p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-medium text-muted-foreground">Balance</p>
          <Wallet className="h-5 w-5 text-primary" />
        </div>
        <p className={`text-3xl font-bold flex items-center gap-1 ${remaining >= 0 ? 'text-success' : 'text-destructive'}`}>
          <IndianRupee className="h-6 w-6" />
          {Math.abs(remaining).toFixed(2)}
        </p>
        <p className="text-xs text-muted-foreground mt-1">
          {remaining >= 0 ? 'Available' : 'Over budget'}
        </p>
      </Card>

      {/* Monthly Budget Usage */}
      <Card className="p-6 hover:shadow-lg transition-shadow">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-medium text-muted-foreground">Monthly Budget</p>
          <PiggyBank className="h-5 w-5 text-primary" />
        </div>
        <p className="text-3xl font-bold text-primary">{percentageUsed.toFixed(0)}%</p>
        <div className="mt-2 h-2 w-full bg-secondary rounded-full overflow-hidden">
          <div
            className={`h-full transition-all ${getProgressColor(percentageUsed)}`}
            style={{ width: `${Math.min(percentageUsed, 100)}%` }}
          />
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          ₹{totalExpenses.toFixed(0)} of ₹{monthlyBudget.toFixed(0)}
        </p>
      </Card>

      {/* Weekly Budget Usage */}
      <Card className="p-6 hover:shadow-lg transition-shadow col-span-1 md:col-span-2 lg:col-span-4">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-medium text-muted-foreground">Weekly Budget Usage</p>
          <PiggyBank className="h-5 w-5 text-accent" />
        </div>
        <div className="flex items-center justify-between">
          <p className="text-2xl font-bold text-accent">{weeklyPercentage.toFixed(0)}%</p>
          <p className="text-sm text-muted-foreground">
            ₹{weeklyExpenses.toFixed(0)} of ₹{weeklyBudget.toFixed(0)} spent this week
          </p>
        </div>
        <div className="mt-2 h-2 w-full bg-secondary rounded-full overflow-hidden">
          <div
            className={`h-full transition-all ${getProgressColor(weeklyPercentage)}`}
            style={{ width: `${Math.min(weeklyPercentage, 100)}%` }}
          />
        </div>
      </Card>
    </div>
  );
};
