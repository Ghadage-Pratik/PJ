import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Settings } from "lucide-react";
import { toast } from "sonner";

interface BudgetManagerProps {
  monthlyBudget: number;
  weeklyBudget: number;
  onUpdateBudget: (monthly: number, weekly: number) => void;
}

export const BudgetManager = ({ monthlyBudget, weeklyBudget, onUpdateBudget }: BudgetManagerProps) => {
  const [newMonthlyBudget, setNewMonthlyBudget] = useState(monthlyBudget.toString());
  const [newWeeklyBudget, setNewWeeklyBudget] = useState(weeklyBudget.toString());
  const [isEditing, setIsEditing] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numMonthly = parseFloat(newMonthlyBudget);
    const numWeekly = parseFloat(newWeeklyBudget);
    
    if (isNaN(numMonthly) || numMonthly < 0 || isNaN(numWeekly) || numWeekly < 0) {
      toast.error("Please enter valid budget amounts");
      return;
    }

    onUpdateBudget(numMonthly, numWeekly);
    setIsEditing(false);
    toast.success("Budget updated successfully!");
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Budget Settings
        </h2>
        {!isEditing && (
          <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
            Edit
          </Button>
        )}
      </div>

      {isEditing ? (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="monthlyBudget">Monthly Budget (₹)</Label>
            <Input
              id="monthlyBudget"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={newMonthlyBudget}
              onChange={(e) => setNewMonthlyBudget(e.target.value)}
              className="text-lg"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="weeklyBudget">Weekly Budget (₹)</Label>
            <Input
              id="weeklyBudget"
              type="number"
              step="0.01"
              placeholder="0.00"
              value={newWeeklyBudget}
              onChange={(e) => setNewWeeklyBudget(e.target.value)}
              className="text-lg"
            />
          </div>
          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              Save
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setNewMonthlyBudget(monthlyBudget.toString());
                setNewWeeklyBudget(weeklyBudget.toString());
                setIsEditing(false);
              }}
              className="flex-1"
            >
              Cancel
            </Button>
          </div>
        </form>
      ) : (
        <div className="space-y-6 py-4">
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">Monthly Budget</p>
            <p className="text-3xl font-bold text-primary">₹{monthlyBudget.toFixed(2)}</p>
          </div>
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">Weekly Budget</p>
            <p className="text-2xl font-bold text-accent">₹{weeklyBudget.toFixed(2)}</p>
          </div>
        </div>
      )}
    </Card>
  );
};
